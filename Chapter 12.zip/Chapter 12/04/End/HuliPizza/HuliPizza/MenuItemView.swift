//
//  MenuItemView.swift
//  HuliPizza
//
//  Created by LinkedIn User on 11/14/22.
//

import SwiftUI
let radialGradient = RadialGradient(colors: [surf,sky], center: .bottom, startRadius: 75, endRadius: 300)
let gradientStops:[Gradient.Stop] = [
    Gradient.Stop(color: surf, location: 0.0),
    Gradient.Stop(color: sky, location: 0.33),
    Gradient.Stop(color: surf, location: 0.95),
    Gradient.Stop(color: sky, location: 1.0)
    
]

let linearStopGradient = LinearGradient(stops: gradientStops, startPoint: .top, endPoint: .bottom)

struct MenuItemView: View {
    @State private var addedItem:Bool = false
    @State private var presentView:Bool = false
    @State private var orderItem:OrderItem = noOrderItem
    @State private var suggestedItem:MenuItem = MenuModel().menu.randomElement() ?? noMenuItem
    @Binding var item:MenuItem
    @ObservedObject var orders:OrderModel
    @Binding var path:NavigationPath
    
    var body: some View {
        VStack {
            HStack {
                Text(item.name)
                    .font(.title)
                    .fontWeight(.semibold)
                    .foregroundStyle(.ultraThickMaterial)
                    .padding(.leading)
                    
                    
                NavigationLink{
                    ItemImageView(item:item)
                } label:{
                    if let image = UIImage(named: "\(item.id)_lg"){
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .padding([.top,.bottom],5)
                        //                    .clipShape(RoundedRectangle(cornerRadius:10))
                            .cornerRadius(15)
                        
                    } else {
                        Image("surfboard_lg")
                            .resizable()
                            .scaledToFit()
                            .rotationEffect(.degrees(180))
                    }
                }
                
            }
            .background(.linearGradient(colors: [.surf,.sky.opacity(0.1)], startPoint: .leading, endPoint: .trailing), in:Capsule())
            .shadow(color:.teal,radius: 5,x:8,y:8)
            VStack(alignment: .leading) {
                
                ScrollView {
                    Text(item.description)
                        .font(.custom("Georgia",size: 18,relativeTo: .body))
                }
                
            }
            NavigationLink(value:suggestedItem){
                VStack{
                    Text("You Might Also Like").textCase(.uppercase).font(.caption)
                    MenuRowView(item:suggestedItem)
                        .foregroundStyle(.primary)
                }
                .padding()
                .background(.regularMaterial)
            }
            .navigationDestination(for: MenuItem.self) { _ in
                MenuItemView(item: $suggestedItem, orders: orders, path: $path)
            }
            HStack{
                Button{
                    orderItem.item = item
                    presentView = true
                } label:{
                    Spacer()
                    Text(item.price,format:.currency(code: "USD")).bold()
                    Image(systemName: addedItem ? "cart.fill.badge.plus" : "cart.badge.plus")
                    Spacer()
                }
                .sheet(isPresented: $presentView) {
                    path = NavigationPath()
                }content: {
                    OrderDetailView(orderItem: $orderItem, presentSheet: $presentView)
                }
                
                .disabled(item.id < 0 )
                .appButtonStyleModifier(backgroundColor: .palm)
                Button{
                    if !path.isEmpty{
                        path.removeLast()
                    }
                } label:{
                    Image(systemName: "chevron.backward")
                }
                .appButtonStyleModifier(backgroundColor: .sky)
                Button{
                    path = NavigationPath()
                } label:{
                    Image(systemName: "chevron.backward.2")
                }
                .appButtonStyleModifier(backgroundColor: .sky)
            }
        }
        .navigationBarBackButtonHidden()
        .toolbarVisibility(.hidden, for: .tabBar)
        .appBackground
    }
}

struct MenuItemView_Previews: PreviewProvider {
    static var previews: some View {
        MenuItemView(item: .constant(testMenuItem), orders: OrderModel(), path: .constant(NavigationPath()))
    }
}
